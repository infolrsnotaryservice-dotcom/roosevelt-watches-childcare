(() => {
const KEY='roosevelt-visual-draft-v1';
const selector='main h1,main h2,main h3,main p,main blockquote,main .eyebrow,main .pill,main .card h3,main .card p,main .owner-badge strong,main .owner-badge small,footer .foot span,footer .foot strong,header .brand';
const elements=[...document.querySelectorAll(selector)].filter(el=>!el.closest('form')&&!el.querySelector('input,textarea,button'));
elements.forEach((el,i)=>{el.dataset.visualEditable=String(i);el.setAttribute('contenteditable','true');el.setAttribute('spellcheck','true')});
const defaults=elements.map(e=>e.innerHTML);
const logo=document.querySelector('.hero-art img'),defaultLogo=logo.getAttribute('src');
const color=document.getElementById('accentColor'),status=document.getElementById('editorStatus');
const state={logo:defaultLogo,accent:'#8064d8'};
function applyAccent(v){document.documentElement.style.setProperty('--purple',v);color.value=v;state.accent=v}
function getDraft(){return {text:elements.map(e=>e.innerHTML),logo:state.logo,accent:state.accent}}
function restore(d){if(!d)return;elements.forEach((e,i)=>{if(typeof d.text?.[i]==='string')e.innerHTML=d.text[i]});if(d.logo){logo.src=d.logo;state.logo=d.logo}if(d.accent)applyAccent(d.accent)}
try{restore(JSON.parse(localStorage.getItem(KEY)||'null'))}catch{}
document.body.classList.add('visual-editing');
let editing=true;
document.getElementById('editToggle').onclick=e=>{editing=!editing;document.body.classList.toggle('visual-editing',editing);elements.forEach(el=>el.setAttribute('contenteditable',String(editing)));e.currentTarget.textContent=editing?'✏️ Editing ON':'👁 Preview Mode';e.currentTarget.setAttribute('aria-pressed',String(editing));status.textContent=editing?'Click any highlighted text to edit.':'Previewing website.'};
document.getElementById('saveDraft').onclick=()=>{try{localStorage.setItem(KEY,JSON.stringify(getDraft()));status.textContent='Saved in this browser! Download the page for a portable copy.'}catch{status.textContent='Browser storage unavailable. Use Download Edited Page.'}};
document.getElementById('logoUpload').onchange=e=>{const f=e.target.files?.[0];if(!f)return;if(f.size>5*1024*1024){status.textContent='Please choose an image under 5 MB.';return}const r=new FileReader();r.onload=()=>{logo.src=r.result;state.logo=r.result;status.textContent='Logo updated. Save Draft or Download Edited Page.'};r.readAsDataURL(f)};
color.oninput=e=>applyAccent(e.target.value);
document.getElementById('resetPage').onclick=()=>{if(!confirm('Restore the original wording, logo and color?'))return;elements.forEach((e,i)=>e.innerHTML=defaults[i]);logo.src=defaultLogo;state.logo=defaultLogo;applyAccent('#8064d8');localStorage.removeItem(KEY);status.textContent='Restored original version.'};
document.getElementById('exportPage').onclick=()=>{
 const doc=document.documentElement.cloneNode(true);
 const toolbar=doc.querySelector('#editbar');toolbar?.remove();
 doc.querySelectorAll('[data-visual-editable]').forEach(e=>{e.removeAttribute('contenteditable');e.removeAttribute('spellcheck');e.removeAttribute('data-visual-editable')});
 doc.querySelector('body')?.classList.remove('visual-editing');
 doc.querySelector('body')?.removeAttribute('style');
 const img=doc.querySelector('.hero-art img');if(img)img.setAttribute('src',state.logo);
 const style=doc.querySelector('head').appendChild(document.createElement('style'));
 style.textContent=':root{--purple:'+state.accent+'!important}body{padding-top:0!important}';
 doc.querySelector('link[href="editor.css"]')?.remove();
 doc.querySelector('script[src="editor.js"]')?.remove();
 const out='<!doctype html>\n'+doc.outerHTML;
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([out],{type:'text/html'}));a.download='index.html';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
 status.textContent='Downloaded! Replace index.html in your website folder with this file.';
};
})();